# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:play_calc',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'A collection of brain games implemented in Python',
    'long_description': '### Hexlet tests and linter status:\n\n[![Hexlet tests and linter status](https://github.com/KahlanRahl/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/KahlanRahl/python-project-49/actions)\n[![Maintainability](https://img.shields.io/codeclimate/maintainability/KahlanRahl/python-project-49)](https://codeclimate.com/github/KahlanRahl/python-project-49)\n\nBrain Games — это набор мини-игр для тренировки мозга. Каждая игра задаёт вопросы, на которые нужно дать правильные ответы. После трёх правильных ответов игра считается пройденной. Неправильный ответ завершает игру и предлагает пройти её заново.\n\n## Установка\n\n1. Убедитесь, что у вас установлены Python 3.10 и Poetry.\n2. Клонируйте репозиторий:\n   ```bash\n   git clone https://github.com/ваш-username/ваш-репозиторий.git\n   cd ваш-репозиторий\n   \n## Пример работы игры\n\n[![asciicast](https://asciinema.org/a/bqllLdv8W1Gszqrxz7Igv8cax.svg)](https://asciinema.org/a/bqllLdv8W1Gszqrxz7Igv8cax)',
    'author': 'KahlanRahl',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
