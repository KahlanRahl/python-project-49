### Hexlet tests and linter status:
[![Actions Status](https://github.com/KahlanRahl/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/KahlanRahl/python-project-49/actions)
[![Maintainability](https://img.shields.io/codeclimate/maintainability/KahlanRahl/python-project-49)](https://codeclimate.com/github/KahlanRahl/python-project-49)